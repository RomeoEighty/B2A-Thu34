#include <stdio.h>

int main()
{
    int tmp, tmp2;
    int* i = &tmp;
    int* sum = &tmp2;  // int *i, *sum;
    *sum = 0;

    for (*i = 0; (*i) <= 10; ++*i) {
        *sum = (*sum) + (*i);
    }

    printf("*sum = %d\n", *sum);

    return 0;
}
